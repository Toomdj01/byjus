var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["266aabdc-faff-455d-9bb0-4b570bd242cd","3713bb60-1ffe-4e67-b047-2acf23d8141f","ba56b326-5932-4d8d-b632-3414986542b6","24da8073-eecd-42cc-a084-7394c6118d0f","71196152-8ba8-4138-9e69-23cd7485a0d2"],"propsByKey":{"266aabdc-faff-455d-9bb0-4b570bd242cd":{"name":"ore_diamond_1","sourceUrl":"assets/api/v1/animation-library/gamelab/4u3N8GIq2HWm5e5wiuwZZFK2FpiCqEyo/category_video_games/ore_diamond.png","frameSize":{"x":128,"y":128},"frameCount":1,"looping":true,"frameDelay":2,"version":"4u3N8GIq2HWm5e5wiuwZZFK2FpiCqEyo","categories":["video_games"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":128,"y":128},"rootRelativePath":"assets/api/v1/animation-library/gamelab/4u3N8GIq2HWm5e5wiuwZZFK2FpiCqEyo/category_video_games/ore_diamond.png"},"3713bb60-1ffe-4e67-b047-2acf23d8141f":{"name":"alienBeige_walk_1","sourceUrl":null,"frameSize":{"x":30,"y":41},"frameCount":2,"looping":true,"frameDelay":12,"version":"OPyHxz7OQAsp1RBUoHy1c_geskFhgrpG","categories":["fantasy"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":60,"y":41},"rootRelativePath":"assets/3713bb60-1ffe-4e67-b047-2acf23d8141f.png"},"ba56b326-5932-4d8d-b632-3414986542b6":{"name":"alienBeige_2","sourceUrl":null,"frameSize":{"x":30,"y":41},"frameCount":1,"looping":true,"frameDelay":12,"version":"rT_URKuzvA4K5GhG.F5_5dLrlypp_CSk","categories":["fantasy"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":30,"y":41},"rootRelativePath":"assets/ba56b326-5932-4d8d-b632-3414986542b6.png"},"24da8073-eecd-42cc-a084-7394c6118d0f":{"name":"alienBeige_duck_1","sourceUrl":null,"frameSize":{"x":30,"y":32},"frameCount":1,"looping":true,"frameDelay":12,"version":"eJaApvOYjFMbrlvog1JeXc6YZqk7at_t","categories":["fantasy"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":30,"y":32},"rootRelativePath":"assets/24da8073-eecd-42cc-a084-7394c6118d0f.png"},"71196152-8ba8-4138-9e69-23cd7485a0d2":{"name":"court_1","sourceUrl":"assets/api/v1/animation-library/gamelab/T.BLfNn.3XTblWtBQ7GC1tSx4_8IsEJV/category_backgrounds/background_court.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"T.BLfNn.3XTblWtBQ7GC1tSx4_8IsEJV","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/T.BLfNn.3XTblWtBQ7GC1tSx4_8IsEJV/category_backgrounds/background_court.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----


var vidas = 3
var gameState = "serve"
var tom = createSprite(15, 380, 4, 4);
var laser1 = createSprite(300, 200, 100, 5);
laser1.shapeColor = "red";
var laser2 = createSprite(100, 300, 100, 5);
laser2.shapeColor = "red";
var laser3 = createSprite(200, 250, 100, 5);
laser3.shapeColor = "red";
var laser4 = createSprite(220, 140, 100, 5);
laser4.shapeColor = "red"
var diamond = createSprite(370, 30, 20, 20);
diamond.shapeColor = "blue"
diamond.setAnimation("ore_diamond_1");
tom.setAnimation("alienBeige_2");
function draw() {
  createEdgeSprites()
  background("white");
  textSize(20)
  text("Vidas  " + vidas ,0, 170)

  if (gameState == "serve") {
    textSize(20);
    text("Presiona espacio para empezar", 0, 200);
  }
  if (keyDown("space")) {
    gameState = "play";
    laser1.velocityX = 13;
    laser2.velocityX = 13;
    laser3.velocityX = 13;
    laser4.velocityX = 13;
  }
  if (gameState == "play") {
    if (keyDown("up")) {
      tom.y = tom.y - 3;
      tom.setAnimation("alienBeige_walk_1");
    }
    if (keyDown("down")) {
      tom.y = tom.y +3
      tom.setAnimation("alienBeige_walk_1");
    }
    if (keyDown("left")) {
      tom.x = tom.x -3
      tom.setAnimation("alienBeige_walk_1");
    }
    if (keyDown("right")) {
      tom.x = tom.x +3
      tom.setAnimation("alienBeige_walk_1");
    }
  }
  if (gameState == "end") {
    tom.setAnimation("alienBeige_duck_1");
    tom.velocityX = 0;
    tom.velocityY = 0;
    laser1.velocityX = 0;
    laser2.velocityX = 0;
    laser3.velocityX = 0;
    laser4.velocityX = 0;
    if (tom.isTouching(diamond)) {
      textSize(20);
      text("El ladrón consiguió el diamante", 0, 200);
    } else {
      (vidas == 0)
      textSize(20);
      text("Ladrón atrapado", 0,200);
    }
  }
  if (tom.isTouching(diamond)){
  gameState = "end"
}

  if (tom.isTouching(laser1) || tom.isTouching(laser2) || tom.isTouching(laser3)|| tom.isTouching(laser4)){
  tom.x = 15
  tom.y = 380
  vidas = vidas - 1
  }
  if (vidas == 0){
    gameState = "end"
  }
  tom.bounceOff(laser1);
  tom.bounceOff(laser2);
  tom.bounceOff(laser3);
  tom.bounceOff(laser4);
  tom.bounceOff(topEdge);
  tom.bounceOff(bottomEdge);
  tom.bounce(leftEdge);
  tom.bounceOff(rightEdge);
  laser1.bounceOff(leftEdge);
  laser1.bounceOff(rightEdge);
  laser2.bounceOff(leftEdge);
  laser2.bounceOff(rightEdge);
  laser3.bounceOff(leftEdge);
  laser3.bounceOff(rightEdge);
  laser4.bounceOff(leftEdge);
  laser4.bounceOff(rightEdge);
  drawSprites();
  
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
